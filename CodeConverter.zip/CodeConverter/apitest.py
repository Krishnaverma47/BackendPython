print("Hello Coder.")
print("Hello Code Converter.")
n = int(input())
for i in range(n):
    print(i,end=" ")