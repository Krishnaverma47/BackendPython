from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import os
from pathlib import Path

script_dir = os.path.dirname(__file__)
st_abs_file_path = os.path.join(script_dir, "static/")

BASE_DIR = Path(__file__).resolve().parent


app = FastAPI()
app.mount("/static", StaticFiles(directory=st_abs_file_path), name="static")
templates = Jinja2Templates(directory=str(Path(BASE_DIR, 'static')))

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("lalit.html", {"request": request})

def start_app():
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
