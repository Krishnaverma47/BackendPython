from fastapi import FastAPI, Request
import uvicorn
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import os
from pathlib import Path


script_dir = os.path.dirname(__file__)
st_abs_file_path = os.path.join(script_dir, "static/")


app = FastAPI()

app.mount("/static", StaticFiles(directory=st_abs_file_path), name="static")


BASE_DIR = Path(__file__).resolve().parent

templates = Jinja2Templates(directory=str(Path(BASE_DIR, 'templates')))


@app.get("/", response_class=HTMLResponse)
async def home(request:Request):
    return templates.TemplateResponse("index.html", {"request": request})


def runApp():
    uvicorn.run(app, host="127.0.0.1", port=8000)
    
if __name__ == '__main__':
    runApp()
